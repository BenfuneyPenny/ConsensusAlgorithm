
require 'rubygems'
require 'bundler/setup'

require File.expand_path('../../../containers/coin_container', __FILE__)

